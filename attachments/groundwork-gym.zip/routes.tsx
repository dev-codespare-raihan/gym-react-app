import { Route, Routes } from "react-router-dom";
import Layout from "./components/Layout";
import Home from "./screens/Home";
import Classes from "./screens/Classes";
import ClassDetail from "./screens/ClassDetail";
import Memberships from "./screens/Memberships";
import Join from "./screens/Join";
import Welcome from "./screens/Welcome";
import Trainers from "./screens/Trainers";
import TrainerProfile from "./screens/TrainerProfile";
import Locations from "./screens/Locations";
import LocationDetail from "./screens/LocationDetail";
import About from "./screens/About";
import Contact from "./screens/Contact";
import NotFound from "./screens/NotFound";

export default function AppRoutes() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/classes" element={<Classes />} />
        <Route path="/classes/:slug" element={<ClassDetail />} />
        <Route path="/memberships" element={<Memberships />} />
        <Route path="/join" element={<Join />} />
        <Route path="/welcome" element={<Welcome />} />
        <Route path="/trainers" element={<Trainers />} />
        <Route path="/trainers/:id" element={<TrainerProfile />} />
        <Route path="/locations" element={<Locations />} />
        <Route path="/locations/:id" element={<LocationDetail />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
