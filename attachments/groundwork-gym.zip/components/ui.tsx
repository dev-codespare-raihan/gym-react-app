import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import {
  classBySlug,
  clubById,
  coachById,
  endTime,
  spotsLeft,
  type Session,
} from "../data";

/* ---------- Layout primitives ---------- */

export function Container({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={"mx-auto w-full max-w-7xl px-5 md:px-8 " + className}>{children}</div>;
}

export function PageHeader({
  title,
  intro,
  children,
}: {
  title: ReactNode;
  intro?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <section className="border-b border-line">
      <Container className="pt-14 pb-10 md:pt-20 md:pb-14">
        <h1 className="animate-fade-in font-display text-6xl font-semibold leading-none tracking-tight md:text-8xl">
          {title}
        </h1>
        {intro && <p className="mt-5 max-w-2xl text-lg text-muted">{intro}</p>}
        {children && <div className="mt-8">{children}</div>}
      </Container>
    </section>
  );
}

/* ---------- Buttons ---------- */

type Variant = "primary" | "secondary" | "secondary-dark" | "ghost";
type Size = "sm" | "md" | "lg";

const BASE =
  "inline-flex items-center justify-center gap-2 rounded-sm font-semibold whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ember disabled:cursor-not-allowed disabled:opacity-40";

const VARIANTS: Record<Variant, string> = {
  primary: "bg-ember text-ink hover:bg-ember-hover",
  secondary: "border border-ink text-ink hover:bg-ink hover:text-on-ink",
  "secondary-dark": "border border-muted-on-ink text-on-ink hover:border-on-ink hover:bg-ink-3",
  ghost: "text-ink hover:text-ember",
};

const SIZES: Record<Size, string> = {
  sm: "h-9 px-3.5 text-sm",
  md: "h-11 px-5 text-base",
  lg: "h-13 px-7 text-lg",
};

export function ButtonLink({
  to,
  variant = "primary",
  size = "md",
  className = "",
  children,
}: {
  to: string;
  variant?: Variant;
  size?: Size;
  className?: string;
  children: ReactNode;
}) {
  return (
    <Link to={to} className={BASE + " " + VARIANTS[variant] + " " + SIZES[size] + " " + className}>
      {children}
    </Link>
  );
}

export function Button({
  variant = "primary",
  size = "md",
  className = "",
  children,
  ...rest
}: {
  variant?: Variant;
  size?: Size;
  className?: string;
  children: ReactNode;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button className={BASE + " " + VARIANTS[variant] + " " + SIZES[size] + " " + className} {...rest}>
      {children}
    </button>
  );
}

/* ---------- Chips (filters) ---------- */

export function Chip({
  active,
  onClick,
  children,
  tone = "light",
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  tone?: "light" | "dark";
}) {
  const cls =
    tone === "dark"
      ? active
        ? "bg-on-ink text-ink border-on-ink"
        : "border-line-on-ink text-muted-on-ink hover:text-on-ink hover:border-muted-on-ink"
      : active
        ? "bg-ink text-on-ink border-ink"
        : "border-line-strong text-muted hover:text-ink hover:border-ink";
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={"h-9 rounded-sm border px-3.5 text-sm font-medium transition-colors " + cls}
    >
      {children}
    </button>
  );
}

/* ---------- Intensity ---------- */

const INTENSITY_LABEL = { 1: "Low", 2: "Moderate", 3: "High" } as const;

export function Intensity({ level, tone = "light" }: { level: 1 | 2 | 3; tone?: "light" | "dark" }) {
  const off = tone === "dark" ? "bg-line-on-ink" : "bg-line-strong";
  return (
    <span className="inline-flex items-center gap-2 text-sm">
      <span className="flex items-end gap-0.5" aria-hidden>
        <span className={"h-2 w-1.5 rounded-[1px] " + (level >= 1 ? "bg-ember" : off)} />
        <span className={"h-3 w-1.5 rounded-[1px] " + (level >= 2 ? "bg-ember" : off)} />
        <span className={"h-4 w-1.5 rounded-[1px] " + (level >= 3 ? "bg-ember" : off)} />
      </span>
      <span>{INTENSITY_LABEL[level]} intensity</span>
    </span>
  );
}

/* ---------- Coach avatar (typographic monogram) ---------- */

const AVATAR_SIZES = {
  sm: "size-10 text-base",
  md: "size-16 text-2xl",
  lg: "size-28 text-5xl",
  xl: "size-full text-8xl",
} as const;

export function CoachAvatar({ initials, size = "md" }: { initials: string; size?: keyof typeof AVATAR_SIZES }) {
  return (
    <span
      aria-hidden
      className={
        "flex shrink-0 items-center justify-center rounded-sm bg-ink font-display font-semibold tracking-tight text-on-ink " +
        AVATAR_SIZES[size]
      }
    >
      {initials}
    </span>
  );
}

/* ---------- Session row: the schedule's core object ---------- */

export function SessionRow({
  session,
  showClub = true,
  showCoach = true,
  tone = "light",
}: {
  session: Session;
  showClub?: boolean;
  showCoach?: boolean;
  tone?: "light" | "dark";
}) {
  const ct = classBySlug(session.classSlug)!;
  const coach = coachById(session.coachId)!;
  const club = clubById(session.clubId)!;
  const left = spotsLeft(session);
  const full = left <= 0;
  const dark = tone === "dark";

  const line = dark ? "border-line-on-ink" : "border-line";
  const muted = dark ? "text-muted-on-ink" : "text-muted";
  const linkHover = dark ? "hover:text-ember" : "hover:text-ember";

  return (
    <li className={"grid grid-cols-[4.5rem_1fr_auto] items-center gap-4 border-t py-4 first:border-t-0 " + line}>
      <div className="font-display text-3xl font-semibold leading-none tabular-nums">{session.time}</div>
      <div className="min-w-0">
        <Link
          to={"/classes/" + ct.slug}
          className={"font-display text-xl font-semibold leading-tight transition-colors " + linkHover}
        >
          {ct.name}
        </Link>
        <div className={"mt-0.5 truncate text-sm " + muted}>
          {showCoach && (
            <Link to={"/trainers/" + coach.id} className="hover:underline">
              {coach.name}
            </Link>
          )}
          {showCoach && showClub && <span aria-hidden> · </span>}
          {showClub && (
            <Link to={"/locations/" + club.id} className="hover:underline">
              {club.name}
            </Link>
          )}
          {(showCoach || showClub) && <span aria-hidden> · </span>}
          <span>until {endTime(session)}</span>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <span className={"hidden text-sm sm:inline " + (full ? muted : left <= 3 ? "font-semibold" : muted)}>
          {full ? "Full" : left === 1 ? "1 spot left" : left + " spots left"}
        </span>
        {full ? (
          <span className={"inline-flex h-9 items-center px-3.5 text-sm " + muted}>Full</span>
        ) : (
          <ButtonLink
            to={"/join?plan=trial&session=" + session.id}
            variant={dark ? "secondary-dark" : "secondary"}
            size="sm"
          >
            Book
          </ButtonLink>
        )}
      </div>
    </li>
  );
}

/* ---------- Section heading ---------- */

export function SectionHeading({
  title,
  action,
  tone = "light",
}: {
  title: ReactNode;
  action?: ReactNode;
  tone?: "light" | "dark";
}) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <h2
        className={
          "font-display text-5xl font-semibold leading-none tracking-tight md:text-6xl " +
          (tone === "dark" ? "text-on-ink" : "text-ink")
        }
      >
        {title}
      </h2>
      {action}
    </div>
  );
}
