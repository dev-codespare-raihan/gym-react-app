import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { BRAND, CLUBS } from "../data";
import { ButtonLink, Container } from "./ui";

const NAV = [
  { to: "/classes", label: "Classes" },
  { to: "/memberships", label: "Memberships" },
  { to: "/trainers", label: "Trainers" },
  { to: "/locations", label: "Locations" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export function Logo({ tone = "light" }: { tone?: "light" | "dark" }) {
  return (
    <Link to="/" className="flex items-center gap-2.5" aria-label="Groundwork home">
      <span className="flex size-6 items-end gap-[3px]" aria-hidden>
        {/* ds-ok: logo mark, three rising bars */}
        <span className="h-2.5 w-1.5 bg-ember" />
        <span className="h-4 w-1.5 bg-ember" />
        <span className="h-6 w-1.5 bg-ember" />
      </span>
      <span
        className={
          "font-display text-2xl font-semibold tracking-tight " + (tone === "dark" ? "text-on-ink" : "text-ink")
        }
      >
        {BRAND.name}
      </span>
    </Link>
  );
}

function Header() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => setOpen(false), [pathname]);

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-paper">
      <Container className="flex h-16 items-center justify-between gap-6">
        <Logo />
        <nav className="hidden items-center gap-7 lg:flex" aria-label="Main">
          {NAV.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              className={({ isActive }) =>
                isActive
                  ? "relative py-5 text-base font-semibold text-ink after:absolute after:inset-x-0 after:bottom-0 after:h-0.5 after:bg-ember"
                  : "py-5 text-base font-medium text-muted transition-colors hover:text-ink"
              }
            >
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <ButtonLink to="/join?plan=trial" size="md" className="hidden sm:inline-flex">
            Book free trial
          </ButtonLink>
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-sm text-ink hover:bg-line lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={22} strokeWidth={1.75} /> : <Menu size={22} strokeWidth={1.75} />}
          </button>
        </div>
      </Container>
      {open && (
        <div className="animate-menu-in border-t border-line bg-paper lg:hidden">
          <Container className="flex flex-col py-3">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                className={({ isActive }) =>
                  isActive
                    ? "border-b border-line py-3.5 font-display text-2xl font-semibold text-ember"
                    : "border-b border-line py-3.5 font-display text-2xl font-semibold text-ink"
                }
              >
                {n.label}
              </NavLink>
            ))}
            <ButtonLink to="/join?plan=trial" size="lg" className="mt-4 sm:hidden">
              Book free trial
            </ButtonLink>
          </Container>
        </div>
      )}
    </header>
  );
}

function FooterCta() {
  return (
    <section className="bg-ember text-ink">
      <Container className="flex flex-col items-start justify-between gap-6 py-14 md:flex-row md:items-center">
        <div>
          <h2 className="font-display text-5xl font-semibold leading-none tracking-tight md:text-7xl">
            Your first 3 classes are free
          </h2>
          <p className="mt-3 text-lg">7 days, any club, no card needed</p>
        </div>
        <Link
          to="/join?plan=trial"
          className="inline-flex h-13 items-center rounded-sm bg-ink px-7 text-lg font-semibold text-on-ink transition-colors hover:bg-ink-3"
        >
          Book free trial
        </Link>
      </Container>
    </section>
  );
}

function Footer({ showCta }: { showCta: boolean }) {
  return (
    <footer>
      {showCta && <FooterCta />}
      <div className="bg-ink text-on-ink">
        <Container className="grid gap-12 py-16 md:grid-cols-12">
          <div className="md:col-span-3">
            <Logo tone="dark" />
            <p className="mt-4 max-w-xs text-muted-on-ink">Coached strength and conditioning in {BRAND.city}.</p>
            <a href={"mailto:" + BRAND.email} className="mt-4 inline-block text-on-ink hover:text-ember">
              {BRAND.email}
            </a>
          </div>
          <div className="grid gap-8 sm:grid-cols-3 md:col-span-7">
            {CLUBS.map((c) => (
              <div key={c.id}>
                <Link to={"/locations/" + c.id} className="font-display text-xl font-semibold hover:text-ember">
                  {c.name}
                </Link>
                <p className="mt-2 text-sm text-muted-on-ink">{c.address}</p>
                <p className="mt-2 text-sm text-muted-on-ink">
                  {c.hours[0].days}, {c.hours[0].time}
                </p>
                <a href={"tel:" + c.phone} className="mt-1 inline-block text-sm text-on-ink hover:text-ember">
                  {c.phone}
                </a>
              </div>
            ))}
          </div>
          <nav className="flex flex-col gap-2 md:col-span-2" aria-label="Footer">
            {NAV.map((n) => (
              <Link key={n.to} to={n.to} className="text-muted-on-ink hover:text-on-ink">
                {n.label}
              </Link>
            ))}
          </nav>
        </Container>
        <Container className="border-t border-line-on-ink py-6 text-sm text-muted-on-ink">
          © 2026 Groundwork Athletic Club
        </Container>
      </div>
    </footer>
  );
}

export default function Layout() {
  const { pathname, search } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname, search]);
  const inFlow = pathname.startsWith("/join") || pathname.startsWith("/welcome");

  return (
    <div className="flex min-h-screen flex-col bg-paper text-foreground">
      <Header />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer showCta={!inFlow} />
    </div>
  );
}
