// Single source of truth for clubs, coaches, classes, the weekly schedule and plans.
// Every page derives its counts and lists from here so nothing contradicts.

export const BRAND = {
  name: "Groundwork",
  city: "Austin",
  email: "hello@groundworkclub.com",
};

const img = (id: string, w = 1600, h = 1000) =>
  `https://images.unsplash.com/photo-${id}?w=${w}&h=${h}&fit=crop`;

export const PHOTOS = {
  weights: img("1534438327276-14e5300c3a48"),
  lifter: img("1517836357463-d25dfeac3438"),
  floor: img("1540497077202-7c8a3999166f"),
  training: img("1571019613454-1cb2f99b2d8b"),
};

export type Club = {
  id: string;
  name: string;
  neighborhood: string;
  address: string;
  phone: string;
  email: string;
  hours: { days: string; time: string }[];
  amenities: string[];
  image: string;
};

export const CLUBS: Club[] = [
  {
    id: "east-side",
    name: "East Side",
    neighborhood: "East Cesar Chavez",
    address: "1100 E 6th St, Austin, TX 78702",
    phone: "(512) 555-0141",
    email: "eastside@groundworkclub.com",
    hours: [
      { days: "Mon to Fri", time: "5:00 to 22:00" },
      { days: "Sat and Sun", time: "7:00 to 20:00" },
    ],
    amenities: ["Lifting platforms", "Boxing bags", "Sauna", "Showers and lockers", "Bike racks"],
    image: PHOTOS.weights,
  },
  {
    id: "south-congress",
    name: "South Congress",
    neighborhood: "Bouldin Creek",
    address: "2400 S Congress Ave, Austin, TX 78704",
    phone: "(512) 555-0162",
    email: "soco@groundworkclub.com",
    hours: [
      { days: "Mon to Fri", time: "5:00 to 22:00" },
      { days: "Sat and Sun", time: "7:00 to 20:00" },
    ],
    amenities: ["Turf track", "Mobility studio", "Showers and lockers", "Parking"],
    image: PHOTOS.floor,
  },
  {
    id: "mueller",
    name: "Mueller",
    neighborhood: "Mueller",
    address: "1801 Aldrich St, Austin, TX 78723",
    phone: "(512) 555-0187",
    email: "mueller@groundworkclub.com",
    hours: [
      { days: "Mon to Fri", time: "5:30 to 21:30" },
      { days: "Sat and Sun", time: "7:00 to 19:00" },
    ],
    amenities: ["Lifting platforms", "Pilates studio", "Kids corner", "Showers and lockers", "Parking"],
    image: PHOTOS.training,
  },
];

export type Coach = {
  id: string;
  name: string;
  initials: string;
  role: string;
  specialties: string[];
  bio: string;
  yearsCoaching: number;
  offersPT: boolean;
};

export const COACHES: Coach[] = [
  {
    id: "maya-ortiz",
    name: "Maya Ortiz",
    initials: "MO",
    role: "Head of strength",
    specialties: ["Barbell strength", "Powerlifting", "Beginners"],
    bio: "Maya built the strength program at Groundwork. She coaches the squat, bench and deadlift with a lot of patience and very clear cues.",
    yearsCoaching: 11,
    offersPT: true,
  },
  {
    id: "dev-patel",
    name: "Dev Patel",
    initials: "DP",
    role: "Conditioning coach",
    specialties: ["Conditioning", "Endurance", "Rowing"],
    bio: "Dev programs the Engine classes. He came from rowing and cares about pacing more than going all out every minute.",
    yearsCoaching: 7,
    offersPT: true,
  },
  {
    id: "jordan-reyes",
    name: "Jordan Reyes",
    initials: "JR",
    role: "Mobility coach",
    specialties: ["Mobility", "Yoga", "Injury return"],
    bio: "Jordan helps lifters move better. Expect slow, deliberate work on hips, shoulders and breathing.",
    yearsCoaching: 9,
    offersPT: false,
  },
  {
    id: "sam-whitfield",
    name: "Sam Whitfield",
    initials: "SW",
    role: "Boxing coach",
    specialties: ["Boxing", "Footwork", "Conditioning"],
    bio: "Sam boxed amateur for a decade. Classes are technique first, with pad work in every session.",
    yearsCoaching: 8,
    offersPT: true,
  },
  {
    id: "priya-nair",
    name: "Priya Nair",
    initials: "PN",
    role: "Pilates coach",
    specialties: ["Mat Pilates", "Core", "Pre and postnatal"],
    bio: "Priya teaches control and core strength that carries over to everything else you do in the gym.",
    yearsCoaching: 6,
    offersPT: false,
  },
  {
    id: "luis-romero",
    name: "Luis Romero",
    initials: "LR",
    role: "Weightlifting coach",
    specialties: ["Olympic lifting", "Power", "Athletes"],
    bio: "Luis coaches the snatch and the clean and jerk. He breaks the lifts into drills anyone can learn.",
    yearsCoaching: 12,
    offersPT: true,
  },
];

export type ClassType = {
  slug: string;
  name: string;
  duration: number; // minutes
  intensity: 1 | 2 | 3;
  capacity: number;
  summary: string;
  description: string;
  whatToBring: string[];
  coachIds: string[];
};

export const CLASS_TYPES: ClassType[] = [
  {
    slug: "barbell-strength",
    name: "Barbell Strength",
    duration: 50,
    intensity: 2,
    capacity: 14,
    summary: "Squat, press and pull with a coach watching every rep",
    description:
      "A structured strength session built around one main barbell lift and two accessory blocks. Weights are scaled to you, and the program runs in 6-week cycles so you can see progress.",
    whatToBring: ["Flat shoes", "Water bottle"],
    coachIds: ["maya-ortiz", "luis-romero"],
  },
  {
    slug: "engine",
    name: "Engine",
    duration: 45,
    intensity: 3,
    capacity: 16,
    summary: "Intervals on rowers, bikes and sleds",
    description:
      "Conditioning built on timed intervals. You'll work on rowers, air bikes and sleds, with pacing targets so you finish strong instead of fading.",
    whatToBring: ["Running shoes", "Towel", "Water bottle"],
    coachIds: ["dev-patel", "sam-whitfield"],
  },
  {
    slug: "box",
    name: "Box",
    duration: 50,
    intensity: 3,
    capacity: 12,
    summary: "Technique, pad work and bag rounds",
    description:
      "Learn to punch properly. Each class covers footwork and one combination, then puts it to work on pads with a partner and on the heavy bags.",
    whatToBring: ["Hand wraps", "Gloves (loaners available)", "Water bottle"],
    coachIds: ["sam-whitfield", "dev-patel"],
  },
  {
    slug: "flow",
    name: "Flow and Mobility",
    duration: 60,
    intensity: 1,
    capacity: 16,
    summary: "Slow mobility work for hips, spine and shoulders",
    description:
      "A recovery class for people who lift. Guided mobility, breathing and light yoga to help you move better and feel better between hard sessions.",
    whatToBring: ["Comfortable clothes", "Mat (provided)"],
    coachIds: ["jordan-reyes", "priya-nair"],
  },
  {
    slug: "core-pilates",
    name: "Core Pilates",
    duration: 45,
    intensity: 1,
    capacity: 14,
    summary: "Mat Pilates for control and core strength",
    description:
      "Mat-based Pilates focused on breathing, alignment and deep core strength. Low impact and suitable for every level.",
    whatToBring: ["Grip socks", "Water bottle"],
    coachIds: ["priya-nair", "jordan-reyes"],
  },
  {
    slug: "lift-lab",
    name: "Lift Lab",
    duration: 60,
    intensity: 2,
    capacity: 10,
    summary: "Learn the snatch and the clean and jerk",
    description:
      "Small-group Olympic weightlifting. Each session breaks a lift into drills, then builds to working sets with feedback on every attempt.",
    whatToBring: ["Lifting shoes if you have them", "Water bottle"],
    coachIds: ["luis-romero", "maya-ortiz"],
  },
];

export const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"] as const;
export const DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

export type Session = {
  id: string;
  day: number; // 0 = Monday
  time: string; // "18:45"
  classSlug: string;
  coachId: string;
  clubId: string;
  capacity: number;
  booked: number;
};

const WEEKDAY_SLOTS = ["06:00", "07:15", "12:15", "17:30", "18:45", "19:45"];
const WEEKEND_SLOTS = ["08:00", "09:30", "11:00"];

function buildSchedule(): Session[] {
  const out: Session[] = [];
  CLUBS.forEach((club, c) => {
    for (let d = 0; d < 7; d++) {
      const slots = d < 5 ? WEEKDAY_SLOTS : WEEKEND_SLOTS;
      slots.forEach((time, s) => {
        const ct = CLASS_TYPES[(c * 2 + d + s) % CLASS_TYPES.length];
        const coachId = ct.coachIds[(d + s + c) % ct.coachIds.length];
        const booked = (c * 7 + d * 5 + s * 11) % (ct.capacity + 1);
        out.push({
          id: `${club.id}-${d}-${time.replace(":", "")}`,
          day: d,
          time,
          classSlug: ct.slug,
          coachId,
          clubId: club.id,
          capacity: ct.capacity,
          booked,
        });
      });
    }
  });
  return out.sort((a, b) => a.day - b.day || a.time.localeCompare(b.time) || a.clubId.localeCompare(b.clubId));
}

export const SCHEDULE: Session[] = buildSchedule();

export type Plan = {
  id: "trial" | "off-peak" | "unlimited" | "coached";
  name: string;
  price: number; // USD per month, 0 for trial
  period: string;
  summary: string;
  features: string[];
  recommended?: boolean;
};

export const PLANS: Plan[] = [
  {
    id: "off-peak",
    name: "Off-peak",
    price: 49,
    period: "/month",
    summary: "For flexible schedules",
    features: ["Open gym 10:00 to 16:00", "Classes that start in that window", "1 home club"],
  },
  {
    id: "unlimited",
    name: "Unlimited",
    price: 89,
    period: "/month",
    summary: "Classes and open gym, every club",
    features: ["Unlimited classes", "Open gym any time", "All 3 clubs", "1 intro session with a coach"],
    recommended: true,
  },
  {
    id: "coached",
    name: "Coached",
    price: 159,
    period: "/month",
    summary: "With a personal coach",
    features: [
      "Everything in Unlimited",
      "2 personal training sessions a month",
      "A program written for you",
      "Progress check every 6 weeks",
    ],
  },
];

export const TRIAL: Plan = {
  id: "trial",
  name: "Free trial",
  price: 0,
  period: "7 days",
  summary: "Try us before you join",
  features: ["Any 3 classes", "Open gym at every club", "No card needed"],
};

export const ALL_PLANS: Plan[] = [TRIAL, ...PLANS];

// Lookups
export const clubById = (id: string) => CLUBS.find((c) => c.id === id);
export const coachById = (id: string) => COACHES.find((c) => c.id === id);
export const classBySlug = (slug: string) => CLASS_TYPES.find((c) => c.slug === slug);
export const planById = (id: string) => ALL_PLANS.find((p) => p.id === id);
export const sessionById = (id: string) => SCHEDULE.find((s) => s.id === id);

export const spotsLeft = (s: Session) => s.capacity - s.booked;

export function endTime(s: Session) {
  const ct = classBySlug(s.classSlug)!;
  const [h, m] = s.time.split(":").map(Number);
  const total = h * 60 + m + ct.duration;
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}

/** Monday = 0 */
export function todayIndex() {
  return (new Date().getDay() + 6) % 7;
}

export function sessionsForDay(day: number, clubId?: string) {
  return SCHEDULE.filter((s) => s.day === day && (!clubId || s.clubId === clubId));
}

export function coachClubs(coachId: string) {
  const ids = new Set(SCHEDULE.filter((s) => s.coachId === coachId).map((s) => s.clubId));
  return CLUBS.filter((c) => ids.has(c.id));
}

export function coachClasses(coachId: string) {
  return CLASS_TYPES.filter((c) => c.coachIds.includes(coachId));
}
