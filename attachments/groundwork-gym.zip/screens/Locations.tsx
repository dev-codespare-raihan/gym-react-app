import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight, MapPin } from "lucide-react";
import { CLUBS } from "../data";
import { Container, PageHeader } from "../components/ui";
import { useScreenInit } from "../useScreenInit";

const PIN_POSITIONS = [
  { id: "east-side", position: "left-[69%] top-[31%]" },
  { id: "south-congress", position: "left-[43%] top-[76%]" },
  { id: "mueller", position: "left-[36%] top-[19%]" },
];

export default function Locations() {
  const initial = useScreenInit();
  const seededClub = typeof initial.club === "string" ? initial.club : "";
  const [selectedClub, setSelectedClub] = useState(CLUBS.some((club) => club.id === seededClub) ? seededClub : "");
  const [hoveredClub, setHoveredClub] = useState("");
  const activeClub = hoveredClub || selectedClub;

  return (
    <>
      <PageHeader title="Locations" />
      <section className="py-12 md:py-16">
        <Container className="grid gap-8 lg:grid-cols-2 lg:gap-12">
          <div
            className="relative aspect-[4/3] overflow-hidden rounded-lg bg-ink"
            role="group"
            aria-label="Schematic map showing the three Groundwork clubs in Austin"
          >
            <div aria-hidden className="absolute inset-0 opacity-60">
              <div className="absolute inset-x-0 top-[25%] border-t border-line-on-ink" />
              <div className="absolute inset-x-0 top-[50%] border-t border-line-on-ink" />
              <div className="absolute inset-x-0 top-[75%] border-t border-line-on-ink" />
              <div className="absolute inset-y-0 left-[25%] border-l border-line-on-ink" />
              <div className="absolute inset-y-0 left-[50%] border-l border-line-on-ink" />
              <div className="absolute inset-y-0 left-[75%] border-l border-line-on-ink" />
              <div className="absolute left-[-8%] top-[58%] h-4 w-[120%] rotate-[-28deg] rounded-full bg-ink-3" />
              <div className="absolute left-[18%] top-[30%] h-3 w-[100%] rotate-[42deg] rounded-full bg-ink-3" />
            </div>
            <div className="absolute bottom-5 left-5 flex items-center gap-2 text-on-ink">
              <MapPin size={18} strokeWidth={1.75} />
              <span className="font-display text-2xl font-semibold tracking-tight">Austin, Texas</span>
            </div>
            {PIN_POSITIONS.map((pin, index) => {
              const club = CLUBS.find((item) => item.id === pin.id);
              if (!club) return null;
              const active = activeClub === club.id;
              return (
                <button
                  key={club.id}
                  type="button"
                  onClick={() => setSelectedClub(selectedClub === club.id ? "" : club.id)}
                  onMouseEnter={() => setHoveredClub(club.id)}
                  onMouseLeave={() => setHoveredClub("")}
                  onFocus={() => setHoveredClub(club.id)}
                  onBlur={() => setHoveredClub("")}
                  aria-label={"Highlight " + club.name + " club"}
                  aria-pressed={active}
                  className={
                    "absolute z-10 flex size-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-2 font-display text-xl font-semibold transition-colors " +
                    pin.position +
                    (active ? " border-ember bg-ember text-ink" : " border-on-ink bg-ink-2 text-on-ink hover:border-ember")
                  }
                >
                  {index + 1}
                </button>
              );
            })}
          </div>

          <ul className="divide-y divide-line border-y border-line">
            {CLUBS.map((club, index) => (
              <li
                key={club.id}
                onMouseEnter={() => setHoveredClub(club.id)}
                onMouseLeave={() => setHoveredClub("")}
                onFocus={() => setHoveredClub(club.id)}
                onBlur={(event) => {
                  if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setHoveredClub("");
                }}
                className={"rounded-sm transition-colors " + (activeClub === club.id ? "bg-card" : "")}
              >
                <div className="grid grid-cols-[5rem_1fr] gap-4 px-3 py-5 sm:grid-cols-[6rem_1fr] sm:px-4">
                  <img src={club.image} alt="" className="aspect-square w-full rounded-sm object-cover" />
                  <div className="min-w-0">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <button
                          type="button"
                          onClick={() => setSelectedClub(selectedClub === club.id ? "" : club.id)}
                          aria-pressed={selectedClub === club.id}
                          className="text-left font-display text-3xl font-semibold leading-none tracking-tight hover:text-ember"
                        >
                          {club.name}
                        </button>
                        <p className="mt-1 text-sm text-muted">{club.neighborhood}</p>
                      </div>
                      <span className="font-display text-2xl font-semibold text-muted" aria-hidden>
                        {String(index + 1).padStart(2, "0")}
                      </span>
                    </div>
                    <p className="mt-3 text-sm">{club.address}</p>
                    <p className="mt-1 text-sm text-muted">
                      {club.hours.map((period) => period.days + " " + period.time).join(" · ")}
                    </p>
                    <a href={"tel:" + club.phone} className="mt-1 inline-block text-sm text-muted hover:text-ink">
                      {club.phone}
                    </a>
                    <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-sm font-semibold">
                      <Link to={"/locations/" + club.id} className="inline-flex items-center gap-1.5 hover:text-ember">
                        View club <ArrowUpRight size={15} strokeWidth={2} />
                      </Link>
                      <a
                        href={"https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(club.address)}
                        target="_blank"
                        rel="noreferrer"
                        className="hover:text-ember"
                      >
                        Get directions
                      </a>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </Container>
      </section>
    </>
  );
}
