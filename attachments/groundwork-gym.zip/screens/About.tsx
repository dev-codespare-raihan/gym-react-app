import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { PHOTOS } from "../data";
import { Container, PageHeader } from "../components/ui";

const PRINCIPLES = [
  ["01", "Coach the person in front of you", "Every class is led by a coach who can adjust the work to your experience and pace."],
  ["02", "Build strength with a plan", "Barbell work, conditioning and skill practice give each session a clear focus."],
  ["03", "Make room to move well", "Mobility and Pilates classes balance the harder work and help you build control."],
];

export default function About() {
  return (
    <>
      <PageHeader title="About Groundwork" intro="Coached strength and conditioning in Austin." />

      <section className="py-16 md:py-24">
        <Container className="grid gap-10 md:grid-cols-12 md:gap-14">
          <h2 className="font-display text-5xl font-semibold leading-none tracking-tight md:col-span-4 md:text-6xl">Training with purpose</h2>
          <div className="space-y-5 text-lg leading-relaxed text-muted md:col-span-7 md:col-start-6">
            <p>Groundwork brings strength, conditioning and skill work together in coached classes across Austin.</p>
            <p>Choose from barbell strength, conditioning, boxing, mobility, Pilates and weightlifting. A coach leads every session, so you can focus on learning the work and building at your own pace.</p>
          </div>
        </Container>
      </section>

      <section className="bg-ink py-16 text-on-ink md:py-24">
        <Container>
          <h2 className="font-display text-5xl font-semibold leading-none tracking-tight md:text-6xl">How we coach</h2>
          <ol className="mt-12 border-t border-line-on-ink">
            {PRINCIPLES.map(([number, title, body]) => (
              <li key={number} className="grid gap-4 border-b border-line-on-ink py-8 md:grid-cols-12 md:gap-8 md:py-10">
                <span className="font-display text-5xl font-semibold leading-none text-ember md:col-span-2">{number}</span>
                <h3 className="font-display text-3xl font-semibold tracking-tight md:col-span-4 md:text-4xl">{title}</h3>
                <p className="max-w-xl text-lg text-muted-on-ink md:col-span-5">{body}</p>
              </li>
            ))}
          </ol>
        </Container>
      </section>

      <section className="py-16 md:py-24">
        <Container>
          <div className="flex flex-wrap items-end justify-between gap-5">
            <h2 className="font-display text-5xl font-semibold leading-none tracking-tight md:text-6xl">Space to train</h2>
            <p className="max-w-md text-lg text-muted">Find the equipment and room for the kind of training you came to do.</p>
          </div>
          <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-12 md:gap-6">
            <figure className="md:col-span-7">
              <img src={PHOTOS.weights} alt="Strength training equipment" className="aspect-[4/3] w-full rounded-lg object-cover" />
              <figcaption className="mt-3 font-display text-2xl font-semibold">Lifting platforms and weights</figcaption>
            </figure>
            <figure className="mt-8 md:col-span-5 md:mt-20">
              <img src={PHOTOS.floor} alt="Open gym training floor" className="aspect-[4/3] w-full rounded-lg object-cover" />
              <figcaption className="mt-3 font-display text-2xl font-semibold">Room to work at your pace</figcaption>
            </figure>
            <figure className="md:col-span-5 md:-mt-8">
              <img src={PHOTOS.training} alt="A coach-led training session" className="aspect-[4/3] w-full rounded-lg object-cover" />
              <figcaption className="mt-3 font-display text-2xl font-semibold">Coached sessions, together</figcaption>
            </figure>
            <div className="flex flex-col justify-center gap-5 py-4 md:col-span-6 md:col-start-7 md:pl-8">
              <Link to="/trainers" className="inline-flex items-center gap-2 font-semibold hover:text-ember">
                Meet the coaches <ArrowRight size={18} strokeWidth={2} />
              </Link>
              <Link to="/locations" className="inline-flex items-center gap-2 font-semibold hover:text-ember">
                Explore our locations <ArrowRight size={18} strokeWidth={2} />
              </Link>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
