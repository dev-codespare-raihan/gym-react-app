import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { CLASS_TYPES, CLUBS, DAYS, SCHEDULE, todayIndex } from "../data";
import { Button, Chip, Container, Intensity, PageHeader, SessionRow } from "../components/ui";
import { useScreenInit } from "../useScreenInit";

function seededDay(value: unknown) {
  return typeof value === "number" && Number.isInteger(value) && value >= 0 && value < DAYS.length
    ? value
    : todayIndex();
}

function seededClub(value: unknown) {
  return typeof value === "string" && CLUBS.some((club) => club.id === value) ? value : "";
}

export default function Classes() {
  const screenState = useScreenInit();
  const [day, setDay] = useState(() => seededDay(screenState.day));
  const [club, setClub] = useState(() => seededClub(screenState.club));
  const [classSlug, setClassSlug] = useState("");

  const sessions = useMemo(
    () => SCHEDULE.filter((session) => session.day === day && (!club || session.clubId === club) && (!classSlug || session.classSlug === classSlug)),
    [day, club, classSlug],
  );
  const filterKey = `${day}-${club}-${classSlug}`;

  function clearFilters() {
    setDay(todayIndex());
    setClub("");
    setClassSlug("");
  }

  return (
    <>
      <PageHeader title="Classes" />
      <section className="py-12 md:py-16">
        <Container>
          <div className="flex flex-wrap gap-2" aria-label="Choose a day">
            {DAYS.map((name, index) => (
              <Chip key={name} active={day === index} onClick={() => setDay(index)}>
                {name}
              </Chip>
            ))}
          </div>

          <div className="mt-7">
            <p className="mb-3 text-sm font-semibold">Club</p>
            <div className="flex flex-wrap gap-2">
              <Chip active={club === ""} onClick={() => setClub("")}>All clubs</Chip>
              {CLUBS.map((item) => (
                <Chip key={item.id} active={club === item.id} onClick={() => setClub(item.id)}>
                  {item.name}
                </Chip>
              ))}
            </div>
          </div>

          <div className="mt-6">
            <p className="mb-3 text-sm font-semibold">Class type</p>
            <div className="flex flex-wrap gap-2">
              <Chip active={classSlug === ""} onClick={() => setClassSlug("")}>All classes</Chip>
              {CLASS_TYPES.map((item) => (
                <Chip key={item.slug} active={classSlug === item.slug} onClick={() => setClassSlug(item.slug)}>
                  {item.name}
                </Chip>
              ))}
            </div>
          </div>

          <div className="mt-8 rounded-lg border border-line bg-card px-5 md:px-6">
            {sessions.length > 0 ? (
              <ul key={filterKey} className="animate-fade-in">
                {sessions.map((session) => <SessionRow key={session.id} session={session} showClub={!club} />)}
              </ul>
            ) : (
              <div className="py-12 text-center">
                <h2 className="font-display text-4xl font-semibold leading-none tracking-tight">No classes match</h2>
                <p className="mt-2 text-muted">Try another day or club</p>
                <Button variant="secondary" className="mt-5" onClick={clearFilters}>Clear filters</Button>
              </div>
            )}
          </div>
        </Container>
      </section>

      <section className="bg-card py-16 md:py-24">
        <Container>
          <h2 className="font-display text-5xl font-semibold leading-none tracking-tight md:text-6xl">Class types</h2>
          <ul className="mt-8 grid border-b border-line sm:grid-cols-2 sm:gap-x-10">
            {CLASS_TYPES.map((item, index) => (
              <li key={item.slug} className="border-t border-line">
                <Link to={`/classes/${item.slug}`} className="group grid grid-cols-[2.5rem_1fr_auto] items-center gap-3 py-5">
                  <span className="font-display text-lg tabular-nums text-muted">{String(index + 1).padStart(2, "0")}</span>
                  <span>
                    <span className="block font-display text-3xl font-semibold leading-none tracking-tight transition-colors group-hover:text-ember">{item.name}</span>
                    <span className="mt-1 block text-sm text-muted">{item.summary}</span>
                    <span className="mt-2 flex flex-wrap items-center gap-x-5 gap-y-1 text-sm text-muted">
                      <span>{item.duration} min</span>
                      <Intensity level={item.intensity} />
                    </span>
                  </span>
                  <ArrowUpRight size={24} strokeWidth={1.75} className="text-line-strong transition-colors group-hover:text-ember" />
                </Link>
              </li>
            ))}
          </ul>
          <Link to="/trainers" className="mt-6 inline-flex items-center gap-2 font-semibold hover:text-ember">
            Meet the trainers <ArrowRight size={18} strokeWidth={2} />
          </Link>
        </Container>
      </section>
    </>
  );
}
