import { useState, type ReactNode } from "react";
import { ArrowLeft, Check } from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { ALL_PLANS, CLUBS, classBySlug, clubById, DAY_NAMES, endTime, planById, sessionById } from "../data";
import { Button, Container } from "../components/ui";
import { useScreenInit } from "../useScreenInit";

type Details = {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  clubId: string;
};

type Payment = {
  cardNumber: string;
  expiry: string;
  cvc: string;
  zip: string;
};

const inputBase = "h-12 w-full rounded-sm border bg-card px-4 focus:border-ink focus:outline-none";
const inputClass = (hasError: boolean) => inputBase + (hasError ? " border-danger" : " border-line-strong");

export default function Join() {
  const location = useLocation();
  const navigate = useNavigate();
  const screenInit = useScreenInit();
  const params = new URLSearchParams(location.search);
  const initialPlanId = params.get("plan") || (typeof screenInit.plan === "string" ? screenInit.plan : "trial");
  const initialPlan = planById(initialPlanId) || ALL_PLANS[0];
  const sessionId = params.get("session") || (typeof screenInit.session === "string" ? screenInit.session : "");
  const session = sessionId ? sessionById(sessionId) : undefined;
  const [planId, setPlanId] = useState(initialPlan.id);
  const plan = planById(planId) || ALL_PLANS[0];
  const stepCount = plan.id === "trial" ? 2 : 3;
  const [step, setStep] = useState(() => {
    const seedStep = typeof screenInit.step === "number" ? screenInit.step : 1;
    return Math.min(Math.max(seedStep, 1), plan.id === "trial" ? 2 : 3);
  });
  const [details, setDetails] = useState<Details>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    clubId: session?.clubId || "",
  });
  const [payment, setPayment] = useState<Payment>({ cardNumber: "", expiry: "", cvc: "", zip: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const updateDetails = (field: keyof Details, value: string) => {
    setDetails((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: "" }));
  };

  const updatePayment = (field: keyof Payment, value: string) => {
    setPayment((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: "" }));
  };

  const validateDetails = () => {
    const next: Record<string, string> = {};
    if (!details.firstName.trim()) next.firstName = "Enter your first name";
    if (!details.lastName.trim()) next.lastName = "Enter your last name";
    if (!details.email.trim()) next.email = "Enter your email";
    else if (!details.email.includes("@")) next.email = "Email must include @";
    if (!details.phone.trim()) next.phone = "Enter your phone number";
    if (!details.clubId) next.clubId = "Choose your home club";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const validatePayment = () => {
    const next: Record<string, string> = {};
    const digits = payment.cardNumber.replace(/\s/g, "");
    if (!digits) next.cardNumber = "Enter your card number";
    else if (!/^\d{15,16}$/.test(digits)) next.cardNumber = "Card number must be 15 or 16 digits";
    if (!payment.expiry.trim()) next.expiry = "Enter the expiration date";
    else if (!/^\d{2}\/\d{2}$/.test(payment.expiry.trim())) next.expiry = "Use MM/YY format";
    if (!payment.cvc.trim()) next.cvc = "Enter your CVC";
    if (!payment.zip.trim()) next.zip = "Enter your ZIP code";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const finishJoin = () => {
    setLoading(true);
    window.setTimeout(() => {
      const query = new URLSearchParams();
      query.set("plan", plan.id);
      if (session) query.set("session", session.id);
      query.set("name", details.firstName.trim());
      navigate("/welcome?" + query.toString());
    }, 900);
  };

  const continueFromDetails = () => {
    if (!validateDetails()) return;
    if (plan.id === "trial") finishJoin();
    else setStep(3);
  };

  const continueFromPayment = () => {
    if (validatePayment()) finishJoin();
  };

  const classType = session ? classBySlug(session.classSlug) : undefined;
  const sessionClub = session ? clubById(session.clubId) : undefined;
  const paidTotal = "$" + plan.price;

  return (
    <section className="py-10 md:py-16">
      <Container>
        <div className="mb-8">
          <Link to="/memberships" className="inline-flex items-center gap-2 text-sm font-semibold text-muted hover:text-ink">
            <ArrowLeft size={17} strokeWidth={1.75} /> Memberships
          </Link>
        </div>
        <div className="grid items-start gap-10 lg:grid-cols-[minmax(0,1fr)_22rem] lg:gap-16">
          <div>
            <p className="text-sm font-semibold text-muted">Step {step} of {stepCount}</p>
            <h1 className="mt-3 font-display text-6xl font-semibold leading-none tracking-tight md:text-7xl">
              {step === 1 ? "Choose your plan" : step === 2 ? "Your details" : "Payment"}
            </h1>

            <div key={step} className="animate-fade-in mt-9">
              {step === 1 && (
                <fieldset>
                  <legend className="sr-only">Choose a plan</legend>
                  <div className="space-y-3">
                    {ALL_PLANS.map((item) => (
                      <label key={item.id} className="flex cursor-pointer items-start gap-4 rounded-md border border-line-strong bg-card p-5 transition-colors has-checked:border-ink">
                        <input
                          type="radio"
                          name="plan"
                          value={item.id}
                          checked={planId === item.id}
                          onChange={() => setPlanId(item.id)}
                          className="mt-1 accent-ink"
                        />
                        <span className="min-w-0 flex-1">
                          <span className="flex flex-wrap items-baseline justify-between gap-2">
                            <span className="font-display text-2xl font-semibold tracking-tight">{item.name}</span>
                            <span className="font-semibold">{item.price === 0 ? "Free for 7 days" : "$" + item.price + item.period}</span>
                          </span>
                          <span className="mt-1 block text-sm text-muted">{item.summary}</span>
                          <span className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted">
                            {item.features.map((feature) => <span key={feature} className="inline-flex items-center gap-1.5"><Check size={15} strokeWidth={1.75} aria-hidden />{feature}</span>)}
                          </span>
                        </span>
                      </label>
                    ))}
                  </div>
                  <Button onClick={() => { setErrors({}); setStep(2); }} size="lg" className="mt-7 w-full sm:w-auto">
                    Continue
                  </Button>
                </fieldset>
              )}

              {step === 2 && (
                <div>
                  <div className="grid gap-5 sm:grid-cols-2">
                    <Field label="First name" error={errors.firstName}>
                      <input id="first-name" className={inputClass(Boolean(errors.firstName))} autoComplete="given-name" value={details.firstName} onChange={(event) => updateDetails("firstName", event.target.value)} />
                    </Field>
                    <Field label="Last name" error={errors.lastName}>
                      <input id="last-name" className={inputClass(Boolean(errors.lastName))} autoComplete="family-name" value={details.lastName} onChange={(event) => updateDetails("lastName", event.target.value)} />
                    </Field>
                    <Field label="Email" error={errors.email}>
                      <input id="email" className={inputClass(Boolean(errors.email))} type="email" autoComplete="email" value={details.email} onChange={(event) => updateDetails("email", event.target.value)} />
                    </Field>
                    <Field label="Phone" error={errors.phone}>
                      <input id="phone" className={inputClass(Boolean(errors.phone))} type="tel" autoComplete="tel" value={details.phone} onChange={(event) => updateDetails("phone", event.target.value)} />
                    </Field>
                    <Field label="Home club" error={errors.clubId}>
                      <select id="home-club" className={inputClass(Boolean(errors.clubId))} value={details.clubId} onChange={(event) => updateDetails("clubId", event.target.value)}>
                        <option value="">Choose a club</option>
                        {CLUBS.map((club) => <option key={club.id} value={club.id}>{club.name}</option>)}
                      </select>
                    </Field>
                  </div>
                  {plan.id !== "trial" && (
                    <Button variant="ghost" onClick={() => { setErrors({}); setStep(1); }} className="mt-7 px-0">
                      <ArrowLeft size={17} strokeWidth={1.75} /> Back
                    </Button>
                  )}
                  <div className="mt-7 flex flex-wrap gap-3">
                    {plan.id === "trial" && <Button variant="ghost" onClick={() => { setErrors({}); setStep(1); }} className="px-0">Back</Button>}
                    <Button onClick={continueFromDetails} size="lg" disabled={loading}>
                      {loading ? "Creating your membership…" : plan.id === "trial" ? "Start free trial" : "Continue"}
                    </Button>
                  </div>
                </div>
              )}

              {step === 3 && plan.id !== "trial" && (
                <div>
                  <div className="grid gap-5 sm:grid-cols-2">
                    <div className="sm:col-span-2">
                      <Field label="Card number" error={errors.cardNumber}>
                        <input id="card-number" className={inputClass(Boolean(errors.cardNumber))} inputMode="numeric" autoComplete="cc-number" maxLength={19} value={payment.cardNumber} onChange={(event) => updatePayment("cardNumber", event.target.value)} />
                      </Field>
                    </div>
                    <Field label="Expiration date" error={errors.expiry}>
                      <input id="expiration-date" className={inputClass(Boolean(errors.expiry))} inputMode="numeric" autoComplete="cc-exp" maxLength={5} value={payment.expiry} onChange={(event) => updatePayment("expiry", event.target.value)} />
                    </Field>
                    <Field label="CVC" error={errors.cvc}>
                      <input id="cvc" className={inputClass(Boolean(errors.cvc))} inputMode="numeric" autoComplete="cc-csc" maxLength={4} value={payment.cvc} onChange={(event) => updatePayment("cvc", event.target.value)} />
                    </Field>
                    <Field label="ZIP code" error={errors.zip}>
                      <input id="zip-code" className={inputClass(Boolean(errors.zip))} autoComplete="postal-code" value={payment.zip} onChange={(event) => updatePayment("zip", event.target.value)} />
                    </Field>
                  </div>
                  <div className="mt-7 flex flex-wrap items-center gap-4">
                    <Button variant="ghost" onClick={() => { setErrors({}); setStep(2); }} className="px-0">
                      <ArrowLeft size={17} strokeWidth={1.75} /> Back
                    </Button>
                    <Button onClick={continueFromPayment} size="lg" disabled={loading}>
                      {loading ? "Creating your membership…" : "Join for $" + plan.price + "/month"}
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>

          <aside className="rounded-lg border border-line bg-card p-6 lg:sticky lg:top-24">
            <h2 className="font-display text-3xl font-semibold tracking-tight">Your plan</h2>
            <div className="mt-5 border-t border-line pt-5">
              <p className="font-semibold">{plan.name}</p>
              <p className="mt-1 text-muted">{plan.price === 0 ? "Free for 7 days" : paidTotal + " today, then " + paidTotal + " each month"}</p>
            </div>
            {session && classType && sessionClub && (
              <div className="mt-6 border-t border-line pt-5">
                <h3 className="font-display text-2xl font-semibold tracking-tight">Your first class</h3>
                <p className="mt-3 font-semibold">{classType.name}</p>
                <p className="mt-1 text-sm text-muted">{DAY_NAMES[session.day]}, {session.time} to {endTime(session)}</p>
                <p className="mt-1 text-sm text-muted">{sessionClub.name}</p>
              </div>
            )}
          </aside>
        </div>
      </Container>
    </section>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: ReactNode }) {
  const id = label.toLowerCase().replace(/ /g, "-");
  return (
    <div>
      <label htmlFor={id} className="mb-2 block font-semibold">{label}</label>
      {children}
      {error && <p className="mt-1.5 text-sm text-danger">{error}</p>}
    </div>
  );
}
