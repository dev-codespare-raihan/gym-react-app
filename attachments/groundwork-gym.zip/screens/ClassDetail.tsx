import { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { CLASS_TYPES, CLUBS, DAY_NAMES, SCHEDULE, coachById } from "../data";
import { ButtonLink, Chip, CoachAvatar, Container, Intensity, PageHeader, SessionRow } from "../components/ui";
import NotFound from "./NotFound";

export default function ClassDetail() {
  const { slug = "" } = useParams();
  const classType = CLASS_TYPES.find((item) => item.slug === slug);
  const [club, setClub] = useState("");
  const sessions = useMemo(
    () => SCHEDULE.filter((session) => session.classSlug === slug && (!club || session.clubId === club)),
    [slug, club],
  );

  if (!classType) return <NotFound />;

  const coaches = classType.coachIds.map(coachById).filter((coach) => coach !== undefined);
  const sessionsByDay = DAY_NAMES.map((name, day) => ({
    name,
    sessions: sessions.filter((session) => session.day === day),
  })).filter((group) => group.sessions.length > 0);

  return (
    <>
      <PageHeader
        title={classType.name}
        intro={classType.summary}
      >
        <Link to="/classes" className="inline-flex items-center gap-2 text-sm font-semibold text-muted hover:text-ink">
          <ArrowLeft size={16} strokeWidth={2} /> All classes
        </Link>
      </PageHeader>

      <section className="py-12 md:py-16">
        <Container>
          <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
            <div className="lg:col-span-7">
              <div className="flex flex-wrap items-center gap-x-6 gap-y-3 border-b border-line pb-6 text-muted">
                <span>{classType.duration} min</span>
                <Intensity level={classType.intensity} />
                <span>Up to {classType.capacity} people</span>
              </div>
              <p className="mt-7 max-w-3xl text-lg leading-relaxed">{classType.description}</p>
              <div className="mt-10">
                <h2 className="font-display text-3xl font-semibold tracking-tight">What to bring</h2>
                <ul className="mt-4 flex flex-wrap gap-x-8 gap-y-2 text-muted">
                  {classType.whatToBring.map((item) => <li key={item}>{item}</li>)}
                </ul>
              </div>
              <div className="mt-10">
                <h2 className="font-display text-3xl font-semibold tracking-tight">Coaches</h2>
                <ul className="mt-4 grid gap-4 sm:grid-cols-2">
                  {coaches.map((coach) => (
                    <li key={coach.id}>
                      <Link to={`/trainers/${coach.id}`} className="group flex items-center gap-3">
                        <CoachAvatar initials={coach.initials} size="md" />
                        <span>
                          <span className="block font-display text-2xl font-semibold leading-tight group-hover:text-ember">{coach.name}</span>
                          <span className="text-sm text-muted">{coach.role}</span>
                        </span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <aside className="lg:col-span-5">
              <ButtonLink to="/join?plan=trial" size="lg">Book free trial</ButtonLink>
            </aside>
          </div>
        </Container>
      </section>

      <section className="bg-card py-16 md:py-24">
        <Container>
          <div className="flex flex-wrap items-end justify-between gap-5">
            <h2 className="font-display text-5xl font-semibold leading-none tracking-tight md:text-6xl">This week</h2>
            <div className="flex flex-wrap gap-2">
              <Chip active={club === ""} onClick={() => setClub("")}>All clubs</Chip>
              {CLUBS.map((item) => (
                <Chip key={item.id} active={club === item.id} onClick={() => setClub(item.id)}>{item.name}</Chip>
              ))}
            </div>
          </div>
          {sessionsByDay.length > 0 ? (
            <div className="mt-8 grid gap-10 lg:grid-cols-2">
              {sessionsByDay.map((group) => (
                <section key={group.name}>
                  <h3 className="mb-2 font-display text-3xl font-semibold tracking-tight">{group.name}</h3>
                  <ul key={`${group.name}-${club}`} className="rounded-lg border border-line bg-paper px-5 md:px-6">
                    {group.sessions.map((session) => <SessionRow key={session.id} session={session} showClub={!club} />)}
                  </ul>
                </section>
              ))}
            </div>
          ) : (
            <p className="mt-8 border-t border-line py-8 text-muted">No sessions are scheduled this week</p>
          )}
        </Container>
      </section>
    </>
  );
}
