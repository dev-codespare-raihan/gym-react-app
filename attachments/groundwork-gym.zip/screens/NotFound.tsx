import { ButtonLink, Container } from "../components/ui";

export default function NotFound() {
  return (
    <Container className="py-32">
      <h1 className="font-display text-7xl font-semibold leading-none tracking-tight">Page not found</h1>
      <p className="mt-4 text-lg text-muted">That page doesn't exist or has moved.</p>
      <ButtonLink to="/" className="mt-8">
        Back to home
      </ButtonLink>
    </Container>
  );
}
