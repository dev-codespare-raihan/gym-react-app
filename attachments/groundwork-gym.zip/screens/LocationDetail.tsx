import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { CLUBS, COACHES, DAY_NAMES, SCHEDULE, sessionsForDay, todayIndex } from "../data";
import { ButtonLink, Chip, CoachAvatar, Container, PageHeader, SessionRow, SectionHeading } from "../components/ui";
import { useScreenInit } from "../useScreenInit";
import NotFound from "./NotFound";

export default function LocationDetail() {
  const { id = "" } = useParams();
  const club = CLUBS.find((item) => item.id === id);
  const initial = useScreenInit();
  const seededDay = typeof initial.day === "number" ? initial.day : todayIndex();
  const [day, setDay] = useState(seededDay >= 0 && seededDay < 7 ? seededDay : todayIndex());

  if (!club) return <NotFound />;

  const sessions = sessionsForDay(day, club.id);
  const coachIds = Array.from(new Set(SCHEDULE.filter((session) => session.clubId === club.id).map((session) => session.coachId)));
  const coaches = COACHES.filter((coach) => coachIds.includes(coach.id));
  const directions = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(club.address);

  return (
    <>
      <PageHeader title={club.name} intro={club.neighborhood}>
        <Link to="/locations" className="inline-flex items-center gap-2 font-semibold hover:text-ember">
          <ArrowLeft size={18} strokeWidth={2} /> All locations
        </Link>
      </PageHeader>

      <section className="py-12 md:py-16">
        <Container>
          <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
            <div className="overflow-hidden rounded-lg bg-line">
              <img src={club.image} alt={"Inside Groundwork " + club.name} className="aspect-[4/3] size-full object-cover" />
            </div>
            <div className="flex flex-col items-start">
              <p className="text-lg text-muted">{club.address}</p>
              <div className="mt-8 flex flex-wrap gap-3">
                <ButtonLink to="/join?plan=trial" size="lg">Book free trial</ButtonLink>
                <a
                  href={directions}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex h-13 items-center gap-2 rounded-sm border border-ink px-7 text-lg font-semibold transition-colors hover:bg-ink hover:text-on-ink"
                >
                  Get directions <ArrowUpRight size={18} strokeWidth={2} />
                </a>
              </div>
              <div className="mt-10 grid w-full gap-9 sm:grid-cols-2">
                <div>
                  <h2 className="font-display text-3xl font-semibold tracking-tight">Hours</h2>
                  <table className="mt-3 w-full border-y border-line text-sm">
                    <tbody>
                      {club.hours.map((period) => (
                        <tr key={period.days} className="border-b border-line last:border-b-0">
                          <th scope="row" className="py-3 text-left font-normal">{period.days}</th>
                          <td className="py-3 text-right text-muted">{period.time}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div>
                  <h2 className="font-display text-3xl font-semibold tracking-tight">Amenities</h2>
                  <ul className="mt-3 divide-y divide-line border-y border-line">
                    {club.amenities.map((amenity) => <li key={amenity} className="py-3 text-sm">{amenity}</li>)}
                  </ul>
                </div>
              </div>
              <div className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm">
                <a href={"tel:" + club.phone} className="font-semibold hover:text-ember">{club.phone}</a>
                <a href={"mailto:" + club.email} className="font-semibold hover:text-ember">{club.email}</a>
              </div>
            </div>
          </div>
        </Container>
      </section>

      <section className="bg-card py-16 md:py-20">
        <Container>
          <SectionHeading title={"This week at " + club.name} />
          <div className="mt-8 flex flex-wrap gap-2" role="group" aria-label="Schedule day">
            {DAY_NAMES.map((name, index) => (
              <Chip key={name} active={day === index} onClick={() => setDay(index)}>
                {name.slice(0, 3)}
              </Chip>
            ))}
          </div>
          <div className="mt-4 rounded-lg border border-line bg-card p-5 md:p-7">
            <ul key={day} className="animate-fade-in">
              {sessions.map((session) => <SessionRow key={session.id} session={session} showClub={false} />)}
            </ul>
          </div>
        </Container>
      </section>

      <section className="py-16 md:py-20">
        <Container>
          <SectionHeading title="Coaches at this club" />
          <ul className="mt-10 grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-6">
            {coaches.map((coach) => (
              <li key={coach.id}>
                <Link to={"/trainers/" + coach.id} className="group block">
                  <CoachAvatar initials={coach.initials} size="xl" />
                  <p className="mt-3 font-display text-2xl font-semibold leading-tight group-hover:text-ember">{coach.name}</p>
                  <p className="text-sm text-muted">{coach.role}</p>
                </Link>
              </li>
            ))}
          </ul>
        </Container>
      </section>
    </>
  );
}
