import { Link, useLocation } from "react-router-dom";
import { classBySlug, clubById, coachById, DAY_NAMES, endTime, planById, sessionById } from "../data";
import { ButtonLink, Container } from "../components/ui";
import { useScreenInit } from "../useScreenInit";

export default function Welcome() {
  const location = useLocation();
  const screenInit = useScreenInit();
  const params = new URLSearchParams(location.search);
  const name = params.get("name") || (typeof screenInit.name === "string" ? screenInit.name : "there");
  const planId = params.get("plan") || (typeof screenInit.plan === "string" ? screenInit.plan : "trial");
  const sessionId = params.get("session") || (typeof screenInit.session === "string" ? screenInit.session : "");
  const plan = planById(planId) || planById("trial")!;
  const session = sessionId ? sessionById(sessionId) : undefined;
  const classType = session ? classBySlug(session.classSlug) : undefined;
  const club = session ? clubById(session.clubId) : undefined;
  const coach = session ? coachById(session.coachId) : undefined;

  return (
    <section className="py-16 md:py-24">
      <Container>
        <div className="max-w-4xl">
          <p className="font-semibold text-muted">{plan.name}{plan.price > 0 ? " · $" + plan.price + plan.period : " · Free for 7 days"}</p>
          <h1 className="mt-4 animate-fade-in font-display text-7xl font-semibold leading-none tracking-tight md:text-9xl">
            You&apos;re in, {name}
          </h1>

          {session && classType && club && coach ? (
            <div className="mt-12 rounded-lg border border-line bg-card p-6 md:p-9">
              <p className="text-sm font-semibold text-muted">Your first class</p>
              <h2 className="mt-2 font-display text-4xl font-semibold leading-none tracking-tight md:text-5xl">{classType.name}</h2>
              <p className="mt-4 text-lg">{DAY_NAMES[session.day]}, {session.time} to {endTime(session)}</p>
              <div className="mt-7 grid gap-7 border-t border-line pt-6 sm:grid-cols-2">
                <div>
                  <h3 className="font-semibold">Club</h3>
                  <p className="mt-1">{club.name}</p>
                  <p className="mt-1 text-muted">{club.address}</p>
                  <Link to={"/locations/" + club.id} className="mt-3 inline-block font-semibold underline underline-offset-4 hover:text-ember">View club</Link>
                </div>
                <div>
                  <h3 className="font-semibold">Coach</h3>
                  <Link to={"/trainers/" + coach.id} className="mt-1 inline-block underline underline-offset-4 hover:text-ember">{coach.name}</Link>
                </div>
                <div className="sm:col-span-2">
                  <h3 className="font-semibold">What to bring</h3>
                  <ul className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-muted">
                    {classType.whatToBring.map((item) => <li key={item}>{item}</li>)}
                  </ul>
                </div>
              </div>
            </div>
          ) : (
            <div className="mt-10">
              <ButtonLink to="/classes" size="lg">Book your first class</ButtonLink>
            </div>
          )}

          <Link to="/" className="mt-8 inline-block font-semibold text-muted hover:text-ink">Back to home</Link>
        </div>
      </Container>
    </section>
  );
}
