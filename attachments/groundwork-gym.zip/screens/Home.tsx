import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import {
  CLASS_TYPES,
  CLUBS,
  COACHES,
  DAY_NAMES,
  PHOTOS,
  PLANS,
  SCHEDULE,
  sessionsForDay,
  todayIndex,
} from "../data";
import { ButtonLink, Chip, CoachAvatar, Container, Intensity, SectionHeading, SessionRow } from "../components/ui";

function nowHHMM() {
  const d = new Date();
  return String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
}

/** Signature: a live "next up" board, the schedule as the hero */
function NextUpBoard() {
  const [club, setClub] = useState<string>("");
  const today = todayIndex();

  const { label, sessions } = useMemo(() => {
    const now = nowHHMM();
    const rest = sessionsForDay(today, club || undefined).filter((s) => s.time > now);
    if (rest.length > 0) return { label: "Today, " + DAY_NAMES[today], sessions: rest.slice(0, 5) };
    const tomorrow = (today + 1) % 7;
    return { label: "Tomorrow, " + DAY_NAMES[tomorrow], sessions: sessionsForDay(tomorrow, club || undefined).slice(0, 5) };
  }, [club, today]);

  return (
    <div className="rounded-lg border border-line-on-ink bg-ink-2 p-5 md:p-6">
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <h2 className="font-display text-3xl font-semibold tracking-tight text-on-ink">Next up</h2>
        <span className="text-sm text-muted-on-ink">{label}</span>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <Chip tone="dark" active={club === ""} onClick={() => setClub("")}>
          All clubs
        </Chip>
        {CLUBS.map((c) => (
          <Chip key={c.id} tone="dark" active={club === c.id} onClick={() => setClub(c.id)}>
            {c.name}
          </Chip>
        ))}
      </div>
      <ul key={club} className="mt-3 animate-fade-in text-on-ink">
        {sessions.map((s) => (
          <SessionRow key={s.id} session={s} tone="dark" showClub={club === ""} />
        ))}
      </ul>
      <Link
        to="/classes"
        className="mt-2 inline-flex items-center gap-1.5 border-t border-line-on-ink pt-4 text-sm font-semibold text-on-ink hover:text-ember"
      >
        Full schedule <ArrowRight size={16} strokeWidth={2} />
      </Link>
    </div>
  );
}

export default function Home() {
  return (
    <>
      {/* Hero */}
      <section className="bg-ink text-on-ink">
        <Container className="grid gap-12 py-16 md:py-24 lg:grid-cols-12 lg:gap-10">
          <div className="flex flex-col justify-center lg:col-span-7">
            <h1 className="animate-fade-in font-display text-7xl font-semibold leading-none tracking-tight md:text-8xl xl:text-9xl">
              <span className="text-ember">Coached</span> strength classes in Austin
            </h1>
            <p className="mt-6 max-w-xl animate-fade-in text-xl text-muted-on-ink [animation-delay:120ms]">
              Small classes, each led by a coach, from 6:00 every morning. Try any 3 free for 7 days.
            </p>
            <div className="mt-9 flex animate-fade-in flex-wrap gap-3 [animation-delay:220ms]">
              <ButtonLink to="/join?plan=trial" size="lg">
                Book free trial
              </ButtonLink>
              <ButtonLink to="/classes" variant="secondary-dark" size="lg">
                View schedule
              </ButtonLink>
            </div>
            <dl className="mt-12 flex flex-wrap gap-x-10 gap-y-4 border-t border-line-on-ink pt-6">
              <div>
                <dt className="text-sm text-muted-on-ink">Clubs</dt>
                <dd className="font-display text-4xl font-semibold">{CLUBS.length}</dd>
              </div>
              <div>
                <dt className="text-sm text-muted-on-ink">Class types</dt>
                <dd className="font-display text-4xl font-semibold">{CLASS_TYPES.length}</dd>
              </div>
              <div>
                <dt className="text-sm text-muted-on-ink">Classes a week</dt>
                <dd className="font-display text-4xl font-semibold">{SCHEDULE.length}</dd>
              </div>
            </dl>
          </div>
          <div className="animate-fade-in lg:col-span-5 [animation-delay:300ms]">
            <NextUpBoard />
          </div>
        </Container>
      </section>

      {/* Classes as an editorial list */}
      <section className="py-20 md:py-28">
        <Container>
          <SectionHeading
            title="Six ways to train"
            action={
              <ButtonLink to="/classes" variant="ghost" className="px-0">
                See the schedule <ArrowRight size={18} strokeWidth={2} />
              </ButtonLink>
            }
          />
          <ul className="mt-12 border-b border-line">
            {CLASS_TYPES.map((c, i) => (
              <li key={c.slug}>
                <Link
                  to={"/classes/" + c.slug}
                  className="group grid grid-cols-12 items-center gap-4 border-t border-line py-6 md:py-7"
                >
                  <span className="col-span-1 font-display text-lg font-medium tabular-nums text-muted">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="col-span-11 font-display text-4xl font-semibold leading-none tracking-tight transition-colors group-hover:text-ember md:col-span-5 md:text-6xl">
                    {c.name}
                  </span>
                  <span className="col-span-11 col-start-2 text-muted md:col-span-3 md:col-start-auto">{c.summary}</span>
                  <span className="col-span-11 col-start-2 flex items-center justify-between gap-4 text-muted md:col-span-3 md:col-start-auto">
                    <span className="flex flex-col gap-1">
                      <span>{c.duration} min</span>
                      <Intensity level={c.intensity} />
                    </span>
                    <ArrowUpRight
                      size={28}
                      strokeWidth={1.75}
                      className="text-line-strong transition-colors group-hover:text-ember"
                    />
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </Container>
      </section>

      {/* Free week */}
      <section className="bg-card py-20 md:py-28">
        <Container className="grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
          <div className="aspect-[4/5] overflow-hidden rounded-lg bg-line">
            <img src={PHOTOS.lifter} alt="A member deadlifting at Groundwork" className="size-full object-cover" />
          </div>
          <div>
            <SectionHeading title="How your free week works" />
            <ol className="mt-10 space-y-8">
              {[
                ["Book a class", "Pick any class on the schedule. No card needed."],
                ["Meet your coach", "Arrive 10 minutes early and your coach will show you around."],
                ["Decide after 7 days", "Use your 3 classes, then choose a plan or walk away."],
              ].map(([t, d], i) => (
                <li key={t} className="grid grid-cols-[3.5rem_1fr] gap-4">
                  <span className="font-display text-6xl font-semibold leading-none text-ember">{i + 1}</span>
                  <div>
                    <h3 className="font-display text-3xl font-semibold tracking-tight">{t}</h3>
                    <p className="mt-1 text-lg text-muted">{d}</p>
                  </div>
                </li>
              ))}
            </ol>
            <ButtonLink to="/join?plan=trial" size="lg" className="mt-10">
              Book free trial
            </ButtonLink>
          </div>
        </Container>
      </section>

      {/* Memberships preview */}
      <section className="py-20 md:py-28">
        <Container>
          <SectionHeading
            title="Memberships"
            action={
              <ButtonLink to="/memberships" variant="ghost" className="px-0">
                Compare plans <ArrowRight size={18} strokeWidth={2} />
              </ButtonLink>
            }
          />
          <div className="mt-12 grid overflow-hidden rounded-lg border border-line bg-card md:grid-cols-3">
            {PLANS.map((p) => (
              <Link
                key={p.id}
                to={"/memberships#" + p.id}
                className={
                  "group relative border-line p-8 transition-colors hover:bg-paper md:border-l md:first:border-l-0 " +
                  "border-t first:border-t-0 md:border-t-0"
                }
              >
                {p.recommended && <span className="absolute inset-x-0 top-0 h-1 bg-ember" aria-hidden />}
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-3xl font-semibold tracking-tight">{p.name}</h3>
                  {p.recommended && <span className="text-sm font-semibold text-ink">Recommended</span>}
                </div>
                <p className="mt-1 text-muted">{p.summary}</p>
                <p className="mt-8 font-display text-6xl font-semibold leading-none tracking-tight">
                  ${p.price}
                  <span className="ml-1 font-sans text-base font-normal text-muted">{p.period}</span>
                </p>
              </Link>
            ))}
          </div>
        </Container>
      </section>

      {/* Locations */}
      <section className="bg-ink py-20 text-on-ink md:py-28">
        <Container>
          <SectionHeading
            tone="dark"
            title="3 clubs across Austin"
            action={
              <Link
                to="/locations"
                className="inline-flex items-center gap-2 font-semibold text-on-ink hover:text-ember"
              >
                All locations <ArrowRight size={18} strokeWidth={2} />
              </Link>
            }
          />
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {CLUBS.map((c) => (
              <Link key={c.id} to={"/locations/" + c.id} className="group">
                <div className="aspect-[4/3] overflow-hidden rounded-lg bg-ink-3">
                  <img
                    src={c.image}
                    alt={"Inside Groundwork " + c.name}
                    className="size-full object-cover opacity-90 transition-opacity group-hover:opacity-100"
                  />
                </div>
                <h3 className="mt-5 font-display text-4xl font-semibold tracking-tight transition-colors group-hover:text-ember">
                  {c.name}
                </h3>
                <p className="mt-1 text-muted-on-ink">{c.address}</p>
                <p className="mt-1 text-muted-on-ink">
                  {c.hours[0].days}, {c.hours[0].time}
                </p>
              </Link>
            ))}
          </div>
        </Container>
      </section>

      {/* Coaches */}
      <section className="py-20 md:py-28">
        <Container>
          <SectionHeading
            title="Meet the coaches"
            action={
              <ButtonLink to="/trainers" variant="ghost" className="px-0">
                All trainers <ArrowRight size={18} strokeWidth={2} />
              </ButtonLink>
            }
          />
          <ul className="mt-12 grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-3 lg:grid-cols-6">
            {COACHES.map((c) => (
              <li key={c.id}>
                <Link to={"/trainers/" + c.id} className="group block">
                  <div className="aspect-square">
                    <CoachAvatar initials={c.initials} size="xl" />
                  </div>
                  <p className="mt-3 font-display text-2xl font-semibold leading-tight transition-colors group-hover:text-ember">
                    {c.name}
                  </p>
                  <p className="text-sm text-muted">{c.role}</p>
                </Link>
              </li>
            ))}
          </ul>
        </Container>
      </section>
    </>
  );
}
