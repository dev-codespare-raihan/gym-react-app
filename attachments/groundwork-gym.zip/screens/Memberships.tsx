import { Check } from "lucide-react";
import { PLANS, TRIAL } from "../data";
import { ButtonLink, Container, PageHeader, SectionHeading } from "../components/ui";

function featureFor(plan: (typeof PLANS)[number], category: "gym" | "classes" | "clubs" | "coaching") {
  const features = plan.features.flatMap((feature) =>
    feature === "Everything in Unlimited"
      ? PLANS.find((item) => item.id === "unlimited")?.features || []
      : [feature],
  );
  const matches = features.filter((feature) => {
    const value = feature.toLowerCase();
    if (category === "gym") return value.includes("open gym");
    if (category === "classes") return value.includes("class");
    if (category === "clubs") return value.includes("club");
    return value.includes("coach") || value.includes("personal training") || value.includes("program") || value.includes("progress");
  });
  return matches.length > 0 ? matches.join(", ") : "Not included";
}

export default function Memberships() {
  return (
    <>
      <PageHeader title="Memberships" />
      <section className="py-14 md:py-20">
        <Container>
          <div className="grid gap-5 md:grid-cols-3">
            {PLANS.map((plan) => (
              <article
                key={plan.id}
                id={plan.id}
                className="scroll-mt-24 relative flex flex-col overflow-hidden rounded-lg border border-line bg-card p-7 md:p-8"
              >
                {plan.recommended && <span className="absolute inset-x-0 top-0 h-1 bg-ember" aria-hidden />}
                <div className="flex items-center justify-between gap-3">
                  <h2 className="font-display text-3xl font-semibold tracking-tight">{plan.name}</h2>
                  {plan.recommended && <span className="text-sm font-semibold text-ink">Recommended</span>}
                </div>
                <p className="mt-1 text-muted">{plan.summary}</p>
                <p className="mt-8 font-display text-6xl font-semibold leading-none tracking-tight">
                  ${plan.price}
                  <span className="ml-1 font-sans text-base font-normal text-muted">{plan.period}</span>
                </p>
                <ul className="mt-8 flex-1 space-y-3 border-t border-line pt-6">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex gap-3 text-sm">
                      <Check size={18} strokeWidth={1.75} className="mt-0.5 shrink-0 text-success" aria-hidden />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <ButtonLink
                  to={"/join?plan=" + plan.id}
                  variant={plan.recommended ? "primary" : "secondary"}
                  className="mt-8 w-full"
                >
                  Choose {plan.name}
                </ButtonLink>
              </article>
            ))}
          </div>
        </Container>
      </section>

      <section className="bg-card py-12 md:py-16">
        <Container className="grid gap-8 md:grid-cols-[1fr_auto] md:items-center">
          <div>
            <p className="text-lg font-semibold">Not ready to join?</p>
            <h2 className="mt-1 font-display text-4xl font-semibold leading-none tracking-tight">Start with a free week</h2>
            <ul className="mt-5 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted">
              {TRIAL.features.map((feature) => (
                <li key={feature} className="flex items-center gap-2">
                  <Check size={16} strokeWidth={1.75} className="text-success" aria-hidden />
                  {feature}
                </li>
              ))}
            </ul>
          </div>
          <ButtonLink to="/join?plan=trial" variant="secondary" size="lg">
            Book free trial
          </ButtonLink>
        </Container>
      </section>

      <section className="py-16 md:py-24">
        <Container>
          <SectionHeading title="Compare plans" />
          <div className="mt-10 overflow-x-auto">
            <table className="w-full min-w-[680px] border-collapse text-left">
              <thead>
                <tr className="border-b border-line-strong">
                  <th className="py-4 pr-5 font-semibold">Included</th>
                  {PLANS.map((plan) => (
                    <th key={plan.id} className="px-5 py-4 font-display text-2xl font-semibold">{plan.name}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {([
                  ["Open gym", "gym"],
                  ["Classes", "classes"],
                  ["Clubs", "clubs"],
                  ["Coaching", "coaching"],
                ] as const).map(([label, category]) => (
                  <tr key={label} className="border-b border-line">
                    <th scope="row" className="py-5 pr-5 font-semibold">{label}</th>
                    {PLANS.map((plan) => (
                      <td key={plan.id} className="px-5 py-5 text-sm text-muted">{featureFor(plan, category)}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Container>
      </section>
    </>
  );
}
