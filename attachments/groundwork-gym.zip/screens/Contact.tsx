import { useState, type FormEvent } from "react";
import { CLUBS, BRAND } from "../data";
import { Button, Container, PageHeader } from "../components/ui";
import { useScreenInit } from "../useScreenInit";

type FormValues = {
  name: string;
  email: string;
  club: string;
  topic: string;
  message: string;
};

type FormErrors = Partial<Record<keyof FormValues, string>>;

const EMPTY_FORM: FormValues = { name: "", email: "", club: "", topic: "", message: "" };
const TOPICS = ["Membership", "Classes", "Personal training", "Something else"];

export default function Contact() {
  const initial = useScreenInit();
  const [sent, setSent] = useState(initial.sent === true);
  const [values, setValues] = useState<FormValues>(EMPTY_FORM);
  const [errors, setErrors] = useState<FormErrors>({});
  const [sending, setSending] = useState(false);

  function update(field: keyof FormValues, value: string) {
    setValues((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const nextErrors: FormErrors = {};
    if (!values.name.trim()) nextErrors.name = "Enter your name";
    if (!values.email.trim()) nextErrors.email = "Enter your email";
    else if (!values.email.includes("@")) nextErrors.email = "Email must include @";
    if (!values.topic) nextErrors.topic = "Choose a topic";
    if (!values.message.trim()) nextErrors.message = "Enter a message";
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setSending(true);
    window.setTimeout(() => {
      setSending(false);
      setSent(true);
    }, 800);
  }

  const inputClass = (field: keyof FormValues) =>
    "h-12 w-full rounded-sm border bg-card px-4 text-ink focus:border-ink focus:outline-none " +
    (errors[field] ? "border-danger" : "border-line-strong");

  return (
    <>
      <PageHeader title="Contact" />
      <section className="py-12 md:py-16">
        <Container className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-7">
            {sent ? (
              <div className="rounded-lg border border-line bg-card p-7 md:p-10" role="status">
                <p className="font-display text-5xl font-semibold leading-none tracking-tight">Message sent</p>
                <p className="mt-4 text-lg text-muted">We'll reply to {values.email || "your email"}</p>
                <Button
                  variant="secondary"
                  className="mt-8"
                  onClick={() => {
                    setSent(false);
                    setValues(EMPTY_FORM);
                    setErrors({});
                  }}
                >
                  Send another
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate>
                <div className="grid gap-6 sm:grid-cols-2">
                  <div>
                    <label htmlFor="contact-name" className="mb-2 block font-semibold">Name</label>
                    <input
                      id="contact-name"
                      name="name"
                      autoComplete="name"
                      className={inputClass("name")}
                      value={values.name}
                      onChange={(event) => update("name", event.target.value)}
                      aria-invalid={Boolean(errors.name)}
                      aria-describedby={errors.name ? "contact-name-error" : undefined}
                      required
                    />
                    {errors.name && <p id="contact-name-error" className="mt-1 text-sm text-danger">{errors.name}</p>}
                  </div>
                  <div>
                    <label htmlFor="contact-email" className="mb-2 block font-semibold">Email</label>
                    <input
                      id="contact-email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      className={inputClass("email")}
                      value={values.email}
                      onChange={(event) => update("email", event.target.value)}
                      aria-invalid={Boolean(errors.email)}
                      aria-describedby={errors.email ? "contact-email-error" : undefined}
                      required
                    />
                    {errors.email && <p id="contact-email-error" className="mt-1 text-sm text-danger">{errors.email}</p>}
                  </div>
                  <div>
                    <label htmlFor="contact-club" className="mb-2 block font-semibold">Club</label>
                    <select
                      id="contact-club"
                      name="club"
                      className={inputClass("club")}
                      value={values.club}
                      onChange={(event) => update("club", event.target.value)}
                    >
                      <option value="">Any club</option>
                      {CLUBS.map((club) => <option key={club.id} value={club.id}>{club.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label htmlFor="contact-topic" className="mb-2 block font-semibold">Topic</label>
                    <select
                      id="contact-topic"
                      name="topic"
                      className={inputClass("topic")}
                      value={values.topic}
                      onChange={(event) => update("topic", event.target.value)}
                      aria-invalid={Boolean(errors.topic)}
                      aria-describedby={errors.topic ? "contact-topic-error" : undefined}
                      required
                    >
                      <option value="" disabled>Choose a topic</option>
                      {TOPICS.map((topic) => <option key={topic} value={topic}>{topic}</option>)}
                    </select>
                    {errors.topic && <p id="contact-topic-error" className="mt-1 text-sm text-danger">{errors.topic}</p>}
                  </div>
                  <div className="sm:col-span-2">
                    <label htmlFor="contact-message" className="mb-2 block font-semibold">Message</label>
                    <textarea
                      id="contact-message"
                      name="message"
                      rows={5}
                      className={"w-full rounded-sm border bg-card px-4 py-3 text-ink focus:border-ink focus:outline-none " +
                        (errors.message ? "border-danger" : "border-line-strong")}
                      value={values.message}
                      onChange={(event) => update("message", event.target.value)}
                      aria-invalid={Boolean(errors.message)}
                      aria-describedby={errors.message ? "contact-message-error" : undefined}
                      required
                    />
                    {errors.message && <p id="contact-message-error" className="mt-1 text-sm text-danger">{errors.message}</p>}
                  </div>
                </div>
                <Button type="submit" size="lg" className="mt-7" disabled={sending}>
                  {sending ? "Sending…" : "Send message"}
                </Button>
              </form>
            )}
          </div>

          <aside className="lg:col-span-5">
            <div className="border-y border-line py-6">
              <h2 className="font-display text-3xl font-semibold tracking-tight">General inquiries</h2>
              <a href={"mailto:" + BRAND.email} className="mt-2 inline-block text-lg font-semibold hover:text-ember">{BRAND.email}</a>
            </div>
            <ul className="divide-y divide-line">
              {CLUBS.map((club) => (
                <li key={club.id} className="py-6">
                  <h3 className="font-display text-3xl font-semibold tracking-tight">{club.name}</h3>
                  <div className="mt-3 flex flex-col items-start gap-1.5 text-sm text-muted">
                    <a href={"tel:" + club.phone} className="hover:text-ink">{club.phone}</a>
                    <a href={"mailto:" + club.email} className="hover:text-ink">{club.email}</a>
                    <a
                      href={"https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(club.address)}
                      target="_blank"
                      rel="noreferrer"
                      className="hover:text-ink"
                    >
                      {club.address}
                    </a>
                    <p>{club.hours.map((period) => period.days + " " + period.time).join(" · ")}</p>
                  </div>
                </li>
              ))}
            </ul>
          </aside>
        </Container>
      </section>
    </>
  );
}
