import { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { CLUBS, DAY_NAMES, SCHEDULE, coachById, coachClasses, coachClubs } from "../data";
import { ButtonLink, Chip, CoachAvatar, Container, PageHeader, SessionRow } from "../components/ui";
import NotFound from "./NotFound";

export default function TrainerProfile() {
  const { id = "" } = useParams();
  const coach = coachById(id);
  const [club, setClub] = useState("");
  const sessions = useMemo(
    () => SCHEDULE.filter((session) => session.coachId === id && (!club || session.clubId === club)),
    [id, club],
  );

  if (!coach) return <NotFound />;

  const classes = coachClasses(coach.id);
  const clubs = coachClubs(coach.id);
  const sessionsByDay = DAY_NAMES.map((name, day) => ({
    name,
    sessions: sessions.filter((session) => session.day === day),
  })).filter((group) => group.sessions.length > 0);

  return (
    <>
      <PageHeader title={coach.name} intro={coach.role}>
        <Link to="/trainers" className="inline-flex items-center gap-2 text-sm font-semibold text-muted hover:text-ink">
          <ArrowLeft size={16} strokeWidth={2} /> All trainers
        </Link>
      </PageHeader>

      <section className="py-12 md:py-16">
        <Container>
          <div className="grid gap-10 lg:grid-cols-12 lg:gap-16">
            <div className="max-w-sm lg:col-span-4">
              <div className="aspect-square">
                <CoachAvatar initials={coach.initials} size="xl" />
              </div>
            </div>
            <div className="lg:col-span-8">
              <p className="max-w-3xl text-lg leading-relaxed">{coach.bio}</p>
              <p className="mt-4 text-muted">{coach.yearsCoaching} years coaching</p>
              <div className="mt-8">
                <h2 className="font-display text-3xl font-semibold tracking-tight">Specialties</h2>
                <p className="mt-2 text-muted">{coach.specialties.join(", ")}</p>
              </div>
              <div className="mt-8">
                <h2 className="font-display text-3xl font-semibold tracking-tight">Clubs</h2>
                <ul className="mt-2 flex flex-wrap gap-x-5 gap-y-2">
                  {clubs.map((item) => (
                    <li key={item.id}><Link to={`/locations/${item.id}`} className="font-medium hover:text-ember">{item.name}</Link></li>
                  ))}
                </ul>
              </div>
              <div className="mt-8">
                <h2 className="font-display text-3xl font-semibold tracking-tight">Classes</h2>
                <ul className="mt-2 flex flex-wrap gap-x-5 gap-y-2">
                  {classes.map((item) => (
                    <li key={item.slug}><Link to={`/classes/${item.slug}`} className="font-medium hover:text-ember">{item.name}</Link></li>
                  ))}
                </ul>
              </div>
              <div className="mt-9">
                {coach.offersPT ? (
                  <ButtonLink to="/join?plan=coached" size="lg">Book personal training</ButtonLink>
                ) : (
                  <p className="text-muted">This trainer doesn't take personal training clients</p>
                )}
              </div>
            </div>
          </div>
        </Container>
      </section>

      <section className="bg-card py-16 md:py-24">
        <Container>
          <div className="flex flex-wrap items-end justify-between gap-5">
            <h2 className="font-display text-5xl font-semibold leading-none tracking-tight md:text-6xl">This week</h2>
            <div className="flex flex-wrap gap-2">
              <Chip active={club === ""} onClick={() => setClub("")}>All clubs</Chip>
              {CLUBS.map((item) => (
                <Chip key={item.id} active={club === item.id} onClick={() => setClub(item.id)}>{item.name}</Chip>
              ))}
            </div>
          </div>
          {sessionsByDay.length > 0 ? (
            <div className="mt-8 grid gap-10 lg:grid-cols-2">
              {sessionsByDay.map((group) => (
                <section key={group.name}>
                  <h3 className="mb-2 font-display text-3xl font-semibold tracking-tight">{group.name}</h3>
                  <ul className="rounded-lg border border-line bg-paper px-5 md:px-6">
                    {group.sessions.map((session) => <SessionRow key={session.id} session={session} showCoach={false} showClub={!club} />)}
                  </ul>
                </section>
              ))}
            </div>
          ) : (
            <p className="mt-8 border-t border-line py-8 text-muted">No sessions are scheduled this week</p>
          )}
        </Container>
      </section>
    </>
  );
}
