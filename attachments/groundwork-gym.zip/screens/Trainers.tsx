import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { CLASS_TYPES, COACHES } from "../data";
import { Chip, CoachAvatar, Container, PageHeader } from "../components/ui";

export default function Trainers() {
  const [classSlug, setClassSlug] = useState("");
  const coaches = useMemo(() => {
    if (!classSlug) return COACHES;
    const classType = CLASS_TYPES.find((item) => item.slug === classSlug);
    return classType ? COACHES.filter((coach) => classType.coachIds.includes(coach.id)) : COACHES;
  }, [classSlug]);

  return (
    <>
      <PageHeader title="Trainers" />
      <section className="py-12 md:py-16">
        <Container>
          <div className="flex flex-wrap gap-2" aria-label="Filter trainers by class type">
            <Chip active={classSlug === ""} onClick={() => setClassSlug("")}>All trainers</Chip>
            {CLASS_TYPES.map((item) => (
              <Chip key={item.slug} active={classSlug === item.slug} onClick={() => setClassSlug(item.slug)}>
                {item.name}
              </Chip>
            ))}
          </div>
          <ul key={classSlug} className="mt-10 grid animate-fade-in grid-cols-2 gap-x-5 gap-y-10 sm:grid-cols-3 lg:grid-cols-6 lg:gap-x-6">
            {coaches.map((coach) => (
              <li key={coach.id}>
                <Link to={`/trainers/${coach.id}`} className="group block">
                  <div className="aspect-square">
                    <CoachAvatar initials={coach.initials} size="xl" />
                  </div>
                  <h2 className="mt-4 font-display text-2xl font-semibold leading-tight tracking-tight transition-colors group-hover:text-ember">{coach.name}</h2>
                  <p className="text-sm text-muted">{coach.role}</p>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{coach.specialties.join(", ")}</p>
                </Link>
              </li>
            ))}
          </ul>
        </Container>
      </section>
    </>
  );
}
